package eya;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Data {

	public static void main(String[] args) throws IOException {
		
		File outFile = new File("Outputcv.txt");
		FileWriter out = new FileWriter(outFile);
		
		String fileName = "data.csv";
		File file = new File(fileName);
		try {
			Scanner inputStream = new Scanner(file);
			String input = "";
			String newInput;
			while(inputStream.hasNext()) {
				String data = inputStream.next();
				//System.out.println(data);
				input += (data + "\r\n");
			}
			out.write(input);
			inputStream.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		out.close();
		
		// traitement du fichier resultat 
		File inFile = new File("Outputcv.txt");
		BufferedReader in = new BufferedReader(new FileReader(inFile));
		File out_File = new File("Out.txt");
		FileWriter outit = new FileWriter(out_File);
		File FifaTabFile = new File("fifa-tab.tsv");
		FileWriter FifaTab = new FileWriter(FifaTabFile);
		String input = "";
		String newInput;
		while((newInput = in.readLine()) != null) {
			String[] lines = newInput.split(",");
			for(String tmpLinne : lines){
				input += (tmpLinne + "	");
			}
		}
		outit.write(input);
		FifaTab.write(input);
		
		outit.close();
		in.close();
		
		
		
	}

}
